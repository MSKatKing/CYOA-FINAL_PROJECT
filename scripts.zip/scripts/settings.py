import pygame

running = False
dimensions = (900, 600)
clock = 0
window = pygame.display.set_mode(dimensions)
state = None
