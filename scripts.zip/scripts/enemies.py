import random


class Enemy:
    def __init__(self, name, health, damageRange):
        self.name = name
        self.health = health
        self.damageRange = damageRange

    def damage(self):
        return random.randint(self.damageRange[0], self.damageRange[1])


class Test(Enemy):
    def __init__(self):
        super().__init__("test", 10, (120, 130))
