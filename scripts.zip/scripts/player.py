import pygame
import settings
import resources


class Player:
    def __init__(self):
        self.images = resources.SpriteSheet("resources/player.png").load_strip((0, 0, 13, 23), 4,
                                                                               (242, 111, 155))  # dim: 121, 55, 77
        for image in self.images:
            self.images[self.images.index(image)] = pygame.transform.scale(image, (39, 69))
        self.rect = self.images[0].get_rect(topleft=(0, 0))
        self.currentImage = self.images[0]
        self.vel = 2.5
        self.animationCycle = 0

    def update(self):
        if self.rect.x > settings.dimensions[0] - 39:
            self.vel = -self.vel
            for i in self.images:
                self.images[self.images.index(i)] = pygame.transform.flip(i, True, False)
        elif self.rect.x < 0:
            self.vel = -self.vel
            for i in self.images:
                self.images[self.images.index(i)] = pygame.transform.flip(i, True, False)

        self.rect.x += self.vel
        settings.window.blit(self.currentImage, self.rect)

    def progressAnimation(self):
        if self.animationCycle > 100:
            self.animationCycle = 0
        elif self.animationCycle > 75:
            self.currentImage = self.images[3]
        elif self.animationCycle > 50:
            self.currentImage = self.images[2]
        elif self.animationCycle > 25:
            self.currentImage = self.images[1]
        elif self.animationCycle > 0:
            self.currentImage = self.images[0]

        self.animationCycle += 2

    def cancelAnimation(self):
        self.animationCycle = 0
        self.currentImage = self.images[0]
