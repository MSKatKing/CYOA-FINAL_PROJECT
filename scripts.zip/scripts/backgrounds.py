import pygame
import settings
import images
import random
import resources
import animations

x = settings.dimensions[0]
y = settings.dimensions[1]

# MAIN MENU ------------------------------------------------------------------------------------------
MMTreesLayer1 = []
for i in range(0, x + 1, 75):
    MMTreesLayer1.append(images.PineTree((i, y - 345)))

for i in range(-38, x + 1, 75):
    MMTreesLayer1.append(images.PineTree((i, y - 310)))

for i in range(0, x + 1, 75):
    MMTreesLayer1.append(images.PineTree((i, y - 275)))

road = images.Road((0, 460))
road2 = images.Road((640, 460))

sun = images.Sun((20, 20))

clouds = [
    images.Cloud((random.randint(0, x), random.randint(0, y - 345))),
    images.Cloud((random.randint(0, x), random.randint(0, y - 345))),
    images.Cloud((random.randint(0, x), random.randint(0, y - 345))),
    images.Cloud((random.randint(0, x), random.randint(0, y - 345))),
    images.Cloud((random.randint(0, x), random.randint(0, y - 345))),
    images.Cloud((random.randint(0, x), random.randint(0, y - 345)))
]

startButton = resources.Button("start_button", (x / 2 - 184 / 2, (y / 2 + 75) - y / 4), (184, 68))
quitButton = resources.Button("quit_button", (x / 2 - 184 / 2, (y / 2 + 3 * 75) - y / 4), (184, 68))
optionsButton = resources.Button("options_button", (x / 2 - 184 / 2, (y / 2 + 2 * 75) - y / 4), (184, 68))


def backgroundMM():
    pygame.draw.rect(settings.window, (0, 150, 240), (0, 0, x, settings.dimensions[1]))
    pygame.draw.rect(settings.window, (21, 50, 30), (0, 350, x, 150))
    for tree in MMTreesLayer1:
        tree.update()
    road.update()
    road2.update()
    sun.update()
    for cloud in clouds:
        if cloud.imageRect.x < -90:
            cloud.imageRect.x = x
            cloud.imageRect.y = random.randint(0, 290)
        cloud.update()


def updateMainMenu():
    backgroundMM()
    if startButton.update() and not animations.slideAnim:
        animations.slideAnimation(resources.States.CHARACTERCUSTOM)
    if quitButton.update():
        settings.running = False
    optionsButton.update()
    pygame.draw.rect(settings.window, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)),
                     (0, 600, 100, 100))


# Test Game Screen  ------------------------------------------------------------------------------------------

backButton = resources.Button("back_button", (10, 10), (92, 34))


def updateTestGame():
    backgroundMM()
    if backButton.update():
        animations.slideAnimation(resources.States.MAINMENU)


def updatePlayerSkin():
    backgroundMM()
    if backButton.update():
        animations.slideAnimation(resources.States.CHARACTERCUSTOM)

# END SCREEN ------------------------------------------------------------------------------------------
