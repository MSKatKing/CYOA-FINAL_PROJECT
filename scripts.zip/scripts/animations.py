import pygame
import settings

slideAnim = False
slideAnimReverse = False
slideAnimOffset = 900
nextState = None


def slideAnimation(state):
    global slideAnim, nextState
    slideAnim = True
    nextState = state
    slideAnimProgress()


def slideAnimProgress():
    global slideAnimOffset, slideAnim, slideAnimReverse, nextState
    if slideAnim:
        if slideAnimReverse:
            slideAnimOffset -= 30
            pygame.draw.rect(settings.window, (0, 0, 0), (slideAnimOffset, 0, 900, 600))
            if slideAnimOffset <= -900:
                slideAnim = False
                slideAnimReverse = False
                slideAnimOffset = 900
                nextState = None
        else:
            slideAnimOffset -= 30
            pygame.draw.rect(settings.window, (0, 0, 0), (slideAnimOffset, 0, 900, 600))
            if slideAnimOffset <= 0:
                slideAnimReverse = True
                settings.state = nextState
