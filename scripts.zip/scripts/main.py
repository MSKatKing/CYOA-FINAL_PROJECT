import inputs
import pygame
import resources
import settings
import sys
import backgrounds
import animations
import player

# TODO:
'''
- add player
    - add sprite
    - add movement
    - add animation(maybe)
- add main menu
    - add character customization
- add gamestates
    - main menu
    - options
    - game
    - end (win)
    - end (lose)
- add good art
    - medium priority
    - player + animation
    - title
    - animal sprites
    - main boss sprite
    - item sprites (maybe)
'''

pygame.init()

settings.clock = pygame.time.Clock()
settings.window = pygame.display.set_mode(settings.dimensions)
pygame.display.set_caption("Choose Your Own Adventure")

playerName = ''
nameInput = resources.TextBox("Welcome to Choose Your Own Adventure!",
                              "Before we begin, we need to get your name... (Please type slowly)",
                              "Please enter your name: ")

skinSelect = resources.TextBox(f"Welcome, {playerName}!",
                              "Please click on a character to select that character.",
                              "Waiting for selection...")

gamePlayer = player.Player()

settings.state = resources.States.MAINMENU
settings.running = True
while settings.running:

    match settings.state:
        case resources.States.MAINMENU:
            backgrounds.updateMainMenu()
            if animations.slideAnim:
                animations.slideAnimProgress()
        case resources.States.MAINGAME:
            backgrounds.updateTestGame()
            if animations.slideAnim:
                animations.slideAnimProgress()
        case resources.States.ENDGAMEWIN:
            if animations.slideAnim:
                animations.slideAnimProgress()
        case resources.States.OPTIONS:
            if animations.slideAnim:
                animations.slideAnimProgress()
        case resources.States.CHARACTERCUSTOM:
            nameInput.setTextL3(f"Please enter your name: {playerName}")
            backgrounds.updateTestGame()
            nameInput.update()
            if animations.slideAnim:
                animations.slideAnimProgress()
        case resources.States.CHARACTERCUSTOMP2:
            backgrounds.updatePlayerSkin()
            skinSelect.setTextL1(f"Welcome, {playerName}!")
            skinSelect.update()
            gamePlayer.update()
            if animations.slideAnim:
                animations.slideAnimProgress()


    # Update Inputs, Clock, and Display
    inputs.updateInputs()
    settings.clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            settings.running = False
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_BACKSPACE:
                playerName = playerName[:-1]
            elif event.key == pygame.K_RETURN:
                animations.slideAnimation(resources.States.CHARACTERCUSTOMP2)
            else:
                playerName += event.unicode
    pygame.display.update()

pygame.quit()
sys.exit()
